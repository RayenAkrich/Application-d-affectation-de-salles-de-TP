package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class EditAccountForm extends javax.swing.JFrame {
    
    private String currentCin; // The current user's CIN, passed from the caller.
    
    public EditAccountForm(String currentCin) {
        initComponents();
        this.currentCin = currentCin;
        loadUserData();
    }
    
        // Load current user's data from the database into the text fields.
    private void loadUserData() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/salle_tp", "root", "123456");
            String query = "SELECT cin, nom, prenom, email, mot_de_passe FROM users WHERE cin = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, currentCin);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                cinLabel.setText(rs.getString("cin"));
                nomTextField.setText(rs.getString("nom"));
                prenomTextField.setText(rs.getString("prenom"));
                emailTextField.setText(rs.getString("email"));
                passwordField.setText(rs.getString("mot_de_passe"));
            } else {
                JOptionPane.showMessageDialog(null, "User not found!");
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch(Exception ex){
            JOptionPane.showMessageDialog(null, "Error loading user data: " + ex.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cinLabel = new javax.swing.JLabel();
        nomTextField = new javax.swing.JTextField();
        prenomTextField = new javax.swing.JTextField();
        emailTextField = new javax.swing.JTextField();
        passwordField = new javax.swing.JPasswordField();
        doneButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cinLabel.setForeground(new java.awt.Color(255, 51, 51));
        getContentPane().add(cinLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 240, 500, 30));

        nomTextField.setBorder(null);
        nomTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(nomTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 320, 510, 40));

        prenomTextField.setBorder(null);
        prenomTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prenomTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(prenomTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 410, 510, 30));

        emailTextField.setBorder(null);
        emailTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(emailTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 500, 510, 30));

        passwordField.setBorder(null);
        passwordField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordFieldActionPerformed(evt);
            }
        });
        getContentPane().add(passwordField, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 590, 510, 40));

        doneButton.setFont(new java.awt.Font("Baskerville Old Face", 1, 36)); // NOI18N
        doneButton.setText("OK");
        doneButton.setBorder(null);
        doneButton.setBorderPainted(false);
        doneButton.setContentAreaFilled(false);
        doneButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        doneButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doneButtonActionPerformed(evt);
            }
        });
        getContentPane().add(doneButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 650, 190, 50));

        backButton.setFont(new java.awt.Font("Baskerville Old Face", 1, 20)); // NOI18N
        backButton.setText("Revenir en arrière");
        backButton.setBorder(null);
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        getContentPane().add(backButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 730, 190, 50));

        exitButton.setForeground(new java.awt.Color(255, 255, 255));
        exitButton.setText("Fermer l'application");
        exitButton.setBorder(null);
        exitButton.setContentAreaFilled(false);
        exitButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        exitButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        exitButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        getContentPane().add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 720, 160, 60));

        Background.setIcon(new javax.swing.ImageIcon("C:\\Users\\topto\\Downloads\\images\\EditACCOUNT.png")); // NOI18N
        getContentPane().add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 800));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void doneButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doneButtonActionPerformed
        // Retrieve new values from fields
        String newNom = nomTextField.getText().trim();
        String newPrenom = prenomTextField.getText().trim();
        String newEmail = emailTextField.getText().trim();
        String newPassword = new String(passwordField.getPassword());
    
        // ---- Validations ----
        if(!newNom.matches("^[A-Za-z\\s\\-']+$")){
            JOptionPane.showMessageDialog(null, "Nom must contain only alphabetic letters.");
            return;
        }
        if(!newPrenom.matches("^[A-Za-z\\s\\-']+$")){
            JOptionPane.showMessageDialog(null, "Prenom must contain only alphabetic letters.");
            return;
        }
        if(!newEmail.matches("^[\\w+.-]+@[\\w.-]+\\.[A-Za-z]{2,}$")){
            JOptionPane.showMessageDialog(null, "Email must be valid, e.g., example@domain.com");
            return;
        }
        if(newPassword.length() <= 5){
            JOptionPane.showMessageDialog(null, "Mot de passe must be more than 5 characters.");
            return;
        }
    
        // ---- Database Update ----
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/salle_tp", "root", "123456")) {
        
            // 1. Check for duplicate email
            String emailCheckQuery = "SELECT * FROM users WHERE email = ? AND cin != ?";
            try (PreparedStatement emailCheckStmt = conn.prepareStatement(emailCheckQuery)) {
                emailCheckStmt.setString(1, newEmail);
                emailCheckStmt.setString(2, currentCin);
                try (ResultSet emailRs = emailCheckStmt.executeQuery()) {
                    if (emailRs.next()) {
                        JOptionPane.showMessageDialog(null, "Email is already in use by another account!");
                        return;  // Exit if email exists
                    }
                }
            }

            // 2. Update user data
            String updateQuery = "UPDATE users SET nom = ?, prenom = ?, email = ?, mot_de_passe = ? WHERE cin = ?";
            try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                updateStmt.setString(1, newNom);
                updateStmt.setString(2, newPrenom);
                updateStmt.setString(3, newEmail);
                updateStmt.setString(4, newPassword);
                updateStmt.setString(5, currentCin);

                int rowsUpdated = updateStmt.executeUpdate();
                if (rowsUpdated > 0) {
                    JOptionPane.showMessageDialog(null, "Account updated successfully!");
                    this.dispose();  // Close the edit form
                    new user_interface(currentCin).setVisible(true);  // Return to user interface
                } else {
                    JOptionPane.showMessageDialog(null, "Update failed. Please try again.");
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }//GEN-LAST:event_doneButtonActionPerformed

    private void nomTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomTextFieldActionPerformed

    }//GEN-LAST:event_nomTextFieldActionPerformed

    private void prenomTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prenomTextFieldActionPerformed

    }//GEN-LAST:event_prenomTextFieldActionPerformed

    private void emailTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailTextFieldActionPerformed

    }//GEN-LAST:event_emailTextFieldActionPerformed

    private void passwordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordFieldActionPerformed

    }//GEN-LAST:event_passwordFieldActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // Close the current form
        this.dispose();
        // Re-open user_interface with the original CIN
        new user_interface(currentCin).setVisible(true);
        
    }//GEN-LAST:event_backButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        dispose();
    }//GEN-LAST:event_exitButtonActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JButton backButton;
    private javax.swing.JLabel cinLabel;
    private javax.swing.JButton doneButton;
    private javax.swing.JTextField emailTextField;
    private javax.swing.JButton exitButton;
    private javax.swing.JTextField nomTextField;
    private javax.swing.JPasswordField passwordField;
    private javax.swing.JTextField prenomTextField;
    // End of variables declaration//GEN-END:variables
}
