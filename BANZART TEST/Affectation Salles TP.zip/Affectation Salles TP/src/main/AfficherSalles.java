package main;
import java.awt.Dimension;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class AfficherSalles extends javax.swing.JFrame {
    
    private String currentCin;
    Connection con;
    Statement stm;
    ResultSet rs;
    PreparedStatement pst;
    public void connect() {
        try {
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/salle_tp", "root", "123456");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "impoo");
        }
    }
    public void Table() {
        try {
            connect();
            String selection = jComboBox1.getSelectedItem().toString();
            String query = "";
    
            // Récupérer le texte saisi dans le JTextField
            String champ = jTextField1.getText().trim(); 
    

            if (selection.equals("Toutes les salles")) {
                query = "SELECT id_salle, nom, capacite, nbr_max_aff FROM salle";
                jTextField1.setEditable(false);
                jTextField1.setText("");
            }else if (selection.equals("Salles par enseignant")) {
                jTextField1.setEditable(true);
                jTextField1.setText("");

                // Réinitialiser le message d'erreur
                lblErreur.setText("");

                if (champ.isEmpty()) {
                    lblErreur.setText("Veuillez entrer un nom d'abord.");
                     return; // Arrêter l'exécution ici
                }

                try {
                    query = "SELECT s.id_salle, s.nom, s.capacite, s.nbr_max_aff, e.nom AS Enseignant "
                        + "FROM salle s "
                        + "JOIN affectation a ON s.id_salle = a.id_salle "
                        + "JOIN enseignant e ON a.id_ens = e.cin AND e.nom LIKE '%" + champ + "%'";
                } catch (Exception e) {
                    lblErreur.setText("Veuillez entrer un enseignant correct.");
                    return;
                }


             // Ajouter la condition de recherche par étudiant si un nom est saisi   
            } else if (selection.equals("Jours libres par salle")) {
                jTextField1.setEditable(true);
                jTextField1.setText("");

                // Réinitialiser le message d'erreur
                lblErreur.setText("");

                if (champ.isEmpty()) {
                    lblErreur.setText("Veuillez entrer un nombre ID valide !");
                    return; // Arrêter l'exécution ici
                }

                try {
                    int idSalle = Integer.parseInt(champ); // Vérifier si c'est un nombre
                    query = "SELECT s.id_salle, s.nom, s.capacite,s.nbr_max_aff, j.jour "
                    + "FROM salle s "
                    + "CROSS JOIN (SELECT 'lundi' AS jour UNION SELECT 'mardi' UNION SELECT 'mercredi' "
                     + "UNION SELECT 'jeudi' UNION SELECT 'vendredi' UNION SELECT 'samedi' UNION SELECT 'dimanche') j "
                    + "LEFT JOIN affectation a ON a.id_salle= s.id_salle "+" AND j.jour = a.jour "
                    + "WHERE a.id_salle IS NULL AND s.id_salle=" + idSalle;
                } catch (NumberFormatException e) {
                    lblErreur.setText("Veuillez entrer un ID de salle valide !");
                    return;
                }


            }else if (selection.equals("Salle la plus affectée")) {
                jTextField1.setEditable(false);
                jTextField1.setText("");
                query = "SELECT s.id_salle, s.nom, s.capacite,s.nbr_max_aff, COUNT(a.id_affect) AS Nbr_Affectations "
                + "FROM salle s "
                + "LEFT JOIN affectation a ON s.id_salle = a.id_salle "
                + "GROUP BY s.id_salle "
                + "ORDER BY Nbr_Affectations DESC LIMIT 1";
    }

    String[] columns = {"ID Salle", "Nom", "Capacité","nbr aff max", "Détails"};
    DefaultTableModel model = new DefaultTableModel(null, columns);

    Statement sta = con.createStatement();
    rs = sta.executeQuery(query);
    if (!rs.isBeforeFirst() && selection.equals("Salles par enseignant")) { // Vérifie si le ResultSet est vide
                lblErreur.setText("Veuillez entrer un enseignant correct.");
            return;}
    while (rs.next()) {
        String[] row = new String[5];
        row[0] = rs.getString("id_salle");
        row[1] = rs.getString("nom");
        row[2] = rs.getString("capacite");
        row[3] =rs.getString("nbr_max_aff");
        if (selection.equals("Salles par enseignant")) {
            row[4] = rs.getString("Enseignant");
        } else if (selection.equals("Jours libres par salle")) {
            row[4] = rs.getString("jour");
            
        } else if (selection.equals("Salle la plus affectée")) {
            row[4] = rs.getString("Nbr_Affectations");
        } else {
            row[4] = "-";
        }
        model.addRow(row);
    }
    TableSalles.setModel(model);
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erreur : " + e.getMessage());
        }
    }

    public AfficherSalles(String cin) {
        initComponents();
        // Configure table header
        JTableHeader header = TableSalles.getTableHeader();
        header.setPreferredSize(new Dimension(header.getWidth(), 50)); // Set header height (e.g., 50px)
        header.setFont(new Font("Segoe UI", Font.BOLD, 24)); // Larger font
        Table();
        this.currentCin = cin;
        setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblErreur = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableSalles = new javax.swing.JTable();
        jComboBox1 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        Confirm = new javax.swing.JButton();
        goBackButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        deconnecterButton = new javax.swing.JButton();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(1280, 800));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblErreur.setBackground(new java.awt.Color(255, 0, 0));
        lblErreur.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(lblErreur, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 710, 200, 50));

        TableSalles.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        TableSalles.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        TableSalles.setRowHeight(90);
        TableSalles.setShowHorizontalLines(true);
        TableSalles.setShowVerticalLines(true);
        TableSalles.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(TableSalles);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 1080, 490));

        jComboBox1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Toutes les salles", "Salles par enseignant", "Jours libres par salle", "Salle la plus affectée" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 40, 250, 50));

        jTextField1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 40, 240, 50));

        Confirm.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Confirm.setForeground(new java.awt.Color(255, 255, 255));
        Confirm.setText("Confirm");
        Confirm.setContentAreaFilled(false);
        Confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmActionPerformed(evt);
            }
        });
        getContentPane().add(Confirm, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 20, 140, 80));

        goBackButton.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        goBackButton.setForeground(new java.awt.Color(255, 255, 255));
        goBackButton.setText("Retour");
        goBackButton.setToolTipText("");
        goBackButton.setBorder(null);
        goBackButton.setBorderPainted(false);
        goBackButton.setContentAreaFilled(false);
        goBackButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        goBackButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        goBackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                goBackButtonActionPerformed(evt);
            }
        });
        getContentPane().add(goBackButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 710, 200, 80));

        exitButton.setForeground(new java.awt.Color(255, 255, 255));
        exitButton.setText("Fermer l'application");
        exitButton.setBorder(null);
        exitButton.setContentAreaFilled(false);
        exitButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        exitButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        exitButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        getContentPane().add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 720, 160, 60));

        deconnecterButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deconnecterButton.setForeground(new java.awt.Color(255, 255, 255));
        deconnecterButton.setText("Se déconnecter");
        deconnecterButton.setBorder(null);
        deconnecterButton.setBorderPainted(false);
        deconnecterButton.setContentAreaFilled(false);
        deconnecterButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        deconnecterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deconnecterButtonActionPerformed(evt);
            }
        });
        getContentPane().add(deconnecterButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 710, 140, 70));

        Background.setIcon(new javax.swing.ImageIcon("C:\\Users\\topto\\Downloads\\images\\AffSalles.jpg")); // NOI18N
        getContentPane().add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 800));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmActionPerformed
        jComboBox1.setSelectedItem(jComboBox1.getSelectedItem());
    }//GEN-LAST:event_ConfirmActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        Table();
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void goBackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_goBackButtonActionPerformed
        new user_interface(currentCin).setVisible(true);
        dispose();
    }//GEN-LAST:event_goBackButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void deconnecterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deconnecterButtonActionPerformed
        new Sign_in().setVisible(true);
        dispose();
    }//GEN-LAST:event_deconnecterButtonActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JButton Confirm;
    private javax.swing.JTable TableSalles;
    private javax.swing.JButton deconnecterButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JButton goBackButton;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lblErreur;
    // End of variables declaration//GEN-END:variables
}
