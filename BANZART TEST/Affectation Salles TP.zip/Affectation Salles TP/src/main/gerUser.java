package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class gerUser extends javax.swing.JFrame {

        Connection conn;
        public void connect() {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/salle_tp", "root", "123456");
                System.out.println("Connected to the database.");
            } catch (ClassNotFoundException | SQLException e) {
                System.out.println("Database connection failed: " + e.getMessage());
            }
        }
        
    public gerUser() {
        initComponents();
        loaduser();
        jPanel1.setVisible(false);
        jTable1.getSelectionModel().addListSelectionListener(e -> {
    if (!e.getValueIsAdjusting() && jTable1.getSelectedRow() != -1) {
        supp.setEnabled(true); // Supprimer
        edit.setEnabled(true); // Modifier
        int selectedRow = jTable1.getSelectedRow();
        cin1.setText(jTable1.getValueAt(selectedRow, 0).toString());
        nom1.setText(jTable1.getValueAt(selectedRow, 1).toString());
        prenom1.setText(jTable1.getValueAt(selectedRow, 2).toString());
        email1.setText(jTable1.getValueAt(selectedRow, 3).toString());
        mdp1.setText(jTable1.getValueAt(selectedRow, 4).toString());
        jComboBox1.setSelectedItem(jTable1.getValueAt(selectedRow, 5).toString());
    }
});
    }
        private void loaduser() {
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0); // Clear table first

    try {
        connect();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM users");

        while (rs.next()) {
            model.addRow(new Object[]{
                    rs.getString("cin"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("email"),
                    rs.getString("mot_de_passe"),
                    rs.getString("role"),
                    rs.getString("date_inscription")
            });
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Erreur de chargement des utilisateurs.");
    }

    // Désactive les boutons tant qu'aucune ligne n'est sélectionnée
    supp.setEnabled(false);
    edit.setEnabled(false);
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        edit = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        cin1 = new javax.swing.JTextField();
        nom1 = new javax.swing.JTextField();
        prenom1 = new javax.swing.JTextField();
        email1 = new javax.swing.JTextField();
        mdp1 = new javax.swing.JTextField();
        add = new javax.swing.JToggleButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        supp = new javax.swing.JButton();
        ajoutpanel = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Information");

        jLabel2.setText("cin :");

        jLabel3.setText("nom :");

        jLabel4.setText("prenom :");

        jLabel5.setText("Email :");

        jLabel6.setText("MDP :");

        jLabel7.setText("Role :");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "admin", "user"}));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        edit.setText("Modifier");
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });

        jButton1.setText("X");
        jButton1.setBorder(new javax.swing.border.MatteBorder(null));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        cin1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cin1ActionPerformed(evt);
            }
        });

        add.setText("Ajouter");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(email1))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(prenom1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cin1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nom1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(mdp1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 94, Short.MAX_VALUE)
                        .addComponent(edit)
                        .addGap(10, 10, 10)))
                .addGap(42, 42, 42))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cin1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(nom1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(prenom1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(email1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(mdp1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(edit)
                    .addComponent(add))
                .addContainerGap(11, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(36, 28, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "cin", "nom", "prenom", "email", "MDP", "role", "D_inscri"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(408, 28, 472, 254));

        supp.setText("Supprimer");
        supp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                suppActionPerformed(evt);
            }
        });
        getContentPane().add(supp, new org.netbeans.lib.awtextra.AbsoluteConstraints(581, 300, -1, -1));

        ajoutpanel.setText("Ajout/Modif");
        ajoutpanel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ajoutpanelActionPerformed(evt);
            }
        });
        getContentPane().add(ajoutpanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(443, 300, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
    String selectedRole = (String) jComboBox1.getSelectedItem();

    if (null == selectedRole) {
        System.out.println("Unknown role selected");
    } else // You can now use this selectedRole value for further logic
        switch (selectedRole) {
            case "admin" -> System.out.println("Admin role selected");
        // Perform actions specific to admin role
            case "user" -> System.out.println("User role selected");
        // Perform actions specific to user role
            default -> System.out.println("Unknown role selected");
        }


    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
    int selectedRow = jTable1.getSelectedRow();

    if (selectedRow != -1) {
        String cinStr = cin1.getText().trim();
        String nom = nom1.getText().trim();
        String prenom = prenom1.getText().trim();
        String email = email1.getText().trim();
        String motDePasse = mdp1.getText().trim();
        String role = jComboBox1.getSelectedItem().toString().trim();

        // Validation 1: CIN doit être exactement 8 chiffres et commencer par 0 ou 1
        if (!cinStr.matches("^[01]\\d{7}$")) {
            JOptionPane.showMessageDialog(this, "CIN doit comporter 8 chiffres et commencer par 0 ou 1.");
            return;
        }

        // Validation 2: NOM doit contenir uniquement des lettres
        if (!nom.matches("^[A-Za-z\\s\\-']+$")) {
            JOptionPane.showMessageDialog(this, "Le nom ne doit contenir que des lettres.");
            return;
        }

        // Validation 3: PRENOM aussi
        if (!prenom.matches("^[A-Za-z\\s\\-']+$")) {
            JOptionPane.showMessageDialog(this, "Le prénom ne doit contenir que des lettres.");
            return;
        }

        // Validation 4: Email format simple
        if (!email.matches("^[\\w.-]+@[\\w.-]+\\.[A-Za-z]{2,}$")) {
            JOptionPane.showMessageDialog(this, "Adresse email invalide.");
            return;
        }

        // Validation 5: Rôle doit être "admin" ou "user"
        if (!role.equals("admin") && !role.equals("user")) {
            JOptionPane.showMessageDialog(this, "Le rôle doit être 'admin' ou 'user'.");
            return;
        }

        try {
            connect();
            String sql = "UPDATE users SET nom = ?, prenom = ?, email = ?, mot_de_passe = ?, role = ? WHERE cin = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nom);
            pstmt.setString(2, prenom);
            pstmt.setString(3, email);
            pstmt.setString(4, motDePasse);
            pstmt.setString(5, role);
            pstmt.setString(6, cinStr);

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Utilisateur CIN " + cinStr + " modifié avec succès !");
                loaduser(); // méthode à définir pour recharger le tableau
            } else {
                JOptionPane.showMessageDialog(this, "Aucune modification effectuée.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erreur lors de la mise à jour.");
        }

    } else {
        JOptionPane.showMessageDialog(this, "Veuillez sélectionner un utilisateur à modifier.");
    }        // TODO add your handling code here:
    }//GEN-LAST:event_editActionPerformed

    private void suppActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_suppActionPerformed
    int selectedRow = jTable1.getSelectedRow();

    if (selectedRow != -1) {
        String cinStr = jTable1.getValueAt(selectedRow, 0).toString(); // colonne 0 = CIN (clé primaire)

        int confirm = JOptionPane.showConfirmDialog(this,
                "Êtes-vous sûr de vouloir supprimer l'utilisateur avec CIN " + cinStr + " ?",
                "Confirmation de suppression", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                connect();
                String sql = "DELETE FROM users WHERE cin = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, cinStr);

                int rowsDeleted = pstmt.executeUpdate();

                if (rowsDeleted > 0) {
                    JOptionPane.showMessageDialog(this, "Utilisateur supprimé avec succès !");
                    loaduser(); // Recharge le tableau après suppression
                } else {
                    JOptionPane.showMessageDialog(this, "Aucune suppression effectuée.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Erreur lors de la suppression.");
            }
        }

    } else {
        JOptionPane.showMessageDialog(this, "Veuillez sélectionner un utilisateur à supprimer.");
    }        // TODO add your handling code here:
    }//GEN-LAST:event_suppActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    jPanel1.setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void ajoutpanelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ajoutpanelActionPerformed
    jPanel1.setVisible(true);  
    jTable1.clearSelection();
    cin1.setText("");
    nom1.setText("");
    prenom1.setText("");
    email1.setText("");
    mdp1.setText("");
    jComboBox1.setSelectedItem("user");
    }//GEN-LAST:event_ajoutpanelActionPerformed

    private void cin1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cin1ActionPerformed

    }//GEN-LAST:event_cin1ActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
    String cinStr = cin1.getText().trim();
    String nom = nom1.getText().trim();
    String prenom = prenom1.getText().trim();
    String email = email1.getText().trim();
    String motDePasse = mdp1.getText().trim();
    String role = jComboBox1.getSelectedItem().toString().trim();
    
    
    // Validation 1: CIN doit être exactement 8 chiffres et commencer par 0 ou 1
    if (!cinStr.matches("^[01]\\d{7}$")) {
        JOptionPane.showMessageDialog(this, "CIN doit comporter 8 chiffres et commencer par 0 ou 1.");
        return;
    }

    // Validation 2: NOM doit contenir uniquement des lettres
    if (!nom.matches("^[A-Za-z\\s\\-']+$")) {
        JOptionPane.showMessageDialog(this, "Le nom ne doit contenir que des lettres.");
        return;
    }

    // Validation 3: PRENOM aussi
    if (!prenom.matches("^[A-Za-z\\s\\-']+$")) {
        JOptionPane.showMessageDialog(this, "Le prénom ne doit contenir que des lettres.");
        return;
    }

    // Validation 4: Email format simple
    if (!email.matches("^[\\w.-]+@[\\w.-]+\\.[A-Za-z]{2,}$")) {
        JOptionPane.showMessageDialog(this, "Adresse email invalide.");
        return;
    }

    // Validation 5: Rôle doit être "admin" ou "user"
    if (!role.equals("admin") && !role.equals("user")) {
        JOptionPane.showMessageDialog(this, "Le rôle doit être 'admin' ou 'user'.");
        return;
    }
    

    
    try {
        connect();
        String checkQuery = "SELECT * FROM users WHERE cin = ? OR email = ?";
        PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
        checkStmt.setString(1, cinStr);
        checkStmt.setString(2, email);
        ResultSet rs = checkStmt.executeQuery();
        if (rs.next()) {
            JOptionPane.showMessageDialog(this, "CIN or email already exists!");
            return;
        }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erreur lors de l'ajout de l'utilisateur.");
        }
        
    try {
        connect();
        String sql = "INSERT INTO users (cin, nom, prenom, email, mot_de_passe, role) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, cinStr);
        pstmt.setString(2, nom);
        pstmt.setString(3, prenom);
        pstmt.setString(4, email);
        pstmt.setString(5, motDePasse);
        pstmt.setString(6, role);

        int rowsInserted = pstmt.executeUpdate();

        if (rowsInserted > 0) {
            JOptionPane.showMessageDialog(this, "Nouvel utilisateur ajouté avec succès !");
            loaduser(); // Recharge le tableau après l'ajout
        } else {
            JOptionPane.showMessageDialog(this, "Aucun utilisateur ajouté.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Erreur lors de l'ajout de l'utilisateur.");
    }     
    }//GEN-LAST:event_addActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new gerUser().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton add;
    private javax.swing.JButton ajoutpanel;
    private javax.swing.JTextField cin1;
    private javax.swing.JButton edit;
    private javax.swing.JTextField email1;
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField mdp1;
    private javax.swing.JTextField nom1;
    private javax.swing.JTextField prenom1;
    private javax.swing.JButton supp;
    // End of variables declaration//GEN-END:variables
}
