package main;

public class AffectationSallesTP {
    
    public static void main(String[] args) {
        
    }
    
}
