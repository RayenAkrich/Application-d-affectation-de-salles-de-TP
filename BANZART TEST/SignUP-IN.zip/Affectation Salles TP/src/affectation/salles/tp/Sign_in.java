package affectation.salles.tp;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class Sign_in extends javax.swing.JFrame {
    
        Connection conn;
        public void connect() {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/salle_tp", "root", "123456");
                System.out.println("Connected to the database.");
            } catch (ClassNotFoundException | SQLException e) {
                System.out.println("Database connection failed: " + e.getMessage());
            }
        }

    public Sign_in() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        EMAIL = new javax.swing.JLabel();
        MDP = new javax.swing.JLabel();
        emailTextField = new javax.swing.JTextField();
        passwordField = new javax.swing.JPasswordField();
        signInButton = new javax.swing.JButton();
        goToSignUpButton = new javax.swing.JButton();
        title = new javax.swing.JLabel();
        NewAccount = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        Background = new javax.swing.JLabel();

        jLabel6.setText("jLabel6");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("SIGN IN");
        setPreferredSize(new java.awt.Dimension(730, 717));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        EMAIL.setFont(new java.awt.Font("Baskerville Old Face", 1, 36)); // NOI18N
        EMAIL.setText("EMAIL :");
        getContentPane().add(EMAIL, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 240, 150, 40));

        MDP.setFont(new java.awt.Font("Baskerville Old Face", 1, 36)); // NOI18N
        MDP.setText("MOT DE PASSE :");
        getContentPane().add(MDP, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 370, -1, -1));

        emailTextField.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        emailTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(emailTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 300, 380, 50));

        passwordField.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        passwordField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordFieldActionPerformed(evt);
            }
        });
        getContentPane().add(passwordField, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 420, 380, 40));

        signInButton.setBackground(new java.awt.Color(0, 0, 102));
        signInButton.setFont(new java.awt.Font("Baskerville Old Face", 1, 36)); // NOI18N
        signInButton.setForeground(new java.awt.Color(255, 255, 255));
        signInButton.setText("SIGN IN");
        signInButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signInButtonActionPerformed(evt);
            }
        });
        getContentPane().add(signInButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 480, 410, 70));

        goToSignUpButton.setBackground(new java.awt.Color(0, 51, 102));
        goToSignUpButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        goToSignUpButton.setForeground(new java.awt.Color(255, 255, 255));
        goToSignUpButton.setText("Go to Sign Up");
        goToSignUpButton.setToolTipText("");
        goToSignUpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                goToSignUpButtonActionPerformed(evt);
            }
        });
        getContentPane().add(goToSignUpButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 560, 150, 50));

        title.setBackground(new java.awt.Color(204, 204, 204));
        title.setFont(new java.awt.Font("Baskerville Old Face", 1, 18)); // NOI18N
        title.setForeground(new java.awt.Color(51, 51, 51));
        title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        title.setText("APPLICATION D'AFFECTATION DE SALLES TP");
        title.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(title, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 430, 70));

        NewAccount.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        NewAccount.setText("Need a new account ?");
        getContentPane().add(NewAccount, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 550, 250, 60));

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 504, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 484, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 140, 510, 490));

        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/signinBackground.png"))); // NOI18N
        getContentPane().add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 740));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    private String authenticateUser(String email, String password) {
        connect();
        String query = "SELECT role FROM user WHERE email = ? AND mot_de_passe = ?";
        try {
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, email);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                // Retourne le rôle de l'utilisateur ("admin" ou "user")
                return rs.getString("role");
            }
        } catch (SQLException ex) {
            System.out.println("Authentication failed: " + ex.getMessage());
        }
        return null; // Authentification échouée
    }
    private void signInButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signInButtonActionPerformed
                                                     
        String email = emailTextField.getText();
        String password = new String(passwordField.getPassword());

        // Récupère le rôle après authentification
        String role = authenticateUser(email, password);

        if (role != null) {
            JOptionPane.showMessageDialog(null, "Sign-in successful as " + role + "!");
        
            // Ouvre l'interface appropriée selon le rôle
            if (role.equalsIgnoreCase("admin")) {
                // Lancer l'interface administrateur
                new admin_interface().setVisible(true);
            } else {
                // Lancer l'interface utilisateur
                new user_interface().setVisible(true);
            }
            dispose();  // Ferme la fenêtre actuelle
        } else {
            JOptionPane.showMessageDialog(null, "Invalid email or password.");
        }
    }//GEN-LAST:event_signInButtonActionPerformed

    private void goToSignUpButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_goToSignUpButtonActionPerformed
        Sign_up signUpForm = new Sign_up();
        signUpForm.setVisible(true);
        dispose();
    }//GEN-LAST:event_goToSignUpButtonActionPerformed

    private void passwordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordFieldActionPerformed

    }//GEN-LAST:event_passwordFieldActionPerformed

    private void emailTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailTextFieldActionPerformed

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Sign_in().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JLabel EMAIL;
    private javax.swing.JLabel MDP;
    private javax.swing.JLabel NewAccount;
    private javax.swing.JTextField emailTextField;
    private javax.swing.JButton goToSignUpButton;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField passwordField;
    private javax.swing.JButton signInButton;
    private javax.swing.JLabel title;
    // End of variables declaration//GEN-END:variables
}
