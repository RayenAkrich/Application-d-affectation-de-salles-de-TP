package affectation.salles.tp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class Sign_up extends javax.swing.JFrame {

        Connection conn;
        public void connect() {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/salle_tp", "root", "123456");
                System.out.println("Connected to the database.");
            } catch (ClassNotFoundException | SQLException e) {
                System.out.println("Database connection failed: " + e.getMessage());
            }
        }
    
    public Sign_up() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        SaisirInfo = new javax.swing.JLabel();
        cinText = new javax.swing.JLabel();
        nomText = new javax.swing.JLabel();
        prenomText = new javax.swing.JLabel();
        emailText = new javax.swing.JLabel();
        password = new javax.swing.JLabel();
        SignIN = new javax.swing.JLabel();
        signUpButton = new javax.swing.JButton();
        goToSignInButton = new javax.swing.JButton();
        cinTextField = new javax.swing.JTextField();
        nomTextField = new javax.swing.JTextField();
        prenomTextField = new javax.swing.JTextField();
        emailTextField = new javax.swing.JTextField();
        passwordField = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(875, 741));
        setSize(new java.awt.Dimension(0, 0));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SaisirInfo.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        SaisirInfo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SaisirInfo.setText("VEUILLEZ SAISIRE VOS INFORMATIONS");
        SaisirInfo.setToolTipText("");
        jPanel1.add(SaisirInfo, new org.netbeans.lib.awtextra.AbsoluteConstraints(76, 9, 512, 40));

        cinText.setFont(new java.awt.Font("Baskerville Old Face", 1, 36)); // NOI18N
        cinText.setText("CIN :");
        jPanel1.add(cinText, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 229, 39));

        nomText.setFont(new java.awt.Font("Baskerville Old Face", 1, 36)); // NOI18N
        nomText.setText("NOM:");
        jPanel1.add(nomText, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 229, 59));

        prenomText.setFont(new java.awt.Font("Baskerville Old Face", 1, 36)); // NOI18N
        prenomText.setText("PRENOM :");
        jPanel1.add(prenomText, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 229, 64));

        emailText.setFont(new java.awt.Font("Baskerville Old Face", 1, 36)); // NOI18N
        emailText.setText("EMAIL :");
        jPanel1.add(emailText, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, 229, 67));

        password.setFont(new java.awt.Font("Baskerville Old Face", 1, 36)); // NOI18N
        password.setText("PASSWORD :");
        jPanel1.add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 350, -1, 68));

        SignIN.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SignIN.setText("Already have an account ?");
        jPanel1.add(SignIN, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 570, 220, 37));

        signUpButton.setBackground(new java.awt.Color(0, 0, 102));
        signUpButton.setFont(new java.awt.Font("Baskerville Old Face", 1, 48)); // NOI18N
        signUpButton.setForeground(new java.awt.Color(255, 255, 255));
        signUpButton.setText("SIGN UP");
        signUpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signUpButtonActionPerformed(evt);
            }
        });
        jPanel1.add(signUpButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 430, 588, 83));

        goToSignInButton.setBackground(new java.awt.Color(0, 0, 102));
        goToSignInButton.setForeground(new java.awt.Color(255, 255, 255));
        goToSignInButton.setText("SIGN IN");
        goToSignInButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                goToSignInButtonActionPerformed(evt);
            }
        });
        jPanel1.add(goToSignInButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 570, 93, 37));

        cinTextField.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cinTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cinTextFieldActionPerformed(evt);
            }
        });
        jPanel1.add(cinTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 80, 292, 39));

        nomTextField.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jPanel1.add(nomTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 150, 290, 40));

        prenomTextField.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prenomTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prenomTextFieldActionPerformed(evt);
            }
        });
        jPanel1.add(prenomTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 220, 290, 40));

        emailTextField.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        emailTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailTextFieldActionPerformed(evt);
            }
        });
        jPanel1.add(emailTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 290, 290, 40));

        passwordField.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jPanel1.add(passwordField, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 360, 290, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 640, 630));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/signupBackground.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -360, 1600, 1600));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void signUpButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signUpButtonActionPerformed
                                                   
        // Get input values from text fields
        String cinStr = cinTextField.getText().trim();
        String nom = nomTextField.getText().trim();
        String prenom = prenomTextField.getText().trim();
        String email = emailTextField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        // ---- Validations ----
        // 1. CIN must be exactly 8 digits and start with 0 or 1.
        if (!cinStr.matches("^[01]\\d{7}$")) {
            JOptionPane.showMessageDialog(null, "CIN must be exactly 8 digits and start with 0 or 1.");
            return;
        }
        // 2. NOM must contain only alphabetic letters.
        if (!nom.matches("^[A-Za-z\\s\\-']+$")) {
            JOptionPane.showMessageDialog(null, "Nom must contain only alphabetic letters.");
            return;
        }
        // 3. PRENOM must contain only alphabetic letters.
        if (!prenom.matches("^^[A-Za-z\\s\\-']+$")) {
            JOptionPane.showMessageDialog(null, "Prenom must contain only alphabetic letters.");
            return;
        }
        // 4. EMAIL must contain an '@' character.
        if (!email.matches("^[\\w+.-]+@[\\w.-]+\\.[A-Za-z]{2,}$")) {
            JOptionPane.showMessageDialog(null, "Email must contain a valid format like 'example@domain.com'.");
            return;
        }
        // 5. MOT DE PASSE must be more than 5 characters.
        if (password.length() <= 5) {
            JOptionPane.showMessageDialog(null, "Mot de passe must be more than 5 characters.");
            return;
        }
        
        // ---- Check if user already exists and register the user ----
        connect();
        if (conn == null) {
            JOptionPane.showMessageDialog(null, "Cannot connect to the database.");
            return;
        }
        
        try {
            // Check if a user with the same CIN or email already exists
            String checkQuery = "SELECT * FROM user WHERE cin = ? OR email = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setString(1, cinStr);
            checkStmt.setString(2, email);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "User with this CIN or email already exists.");
                return;
            }
            
            // Insert the new user; role is set to 'user' by default, and date_inscription is auto-set.
            String insertQuery = "INSERT INTO user (cin, nom, prenom, email, mot_de_passe, role) VALUES (?, ?, ?, ?, ?, 'user')";
            PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
            insertStmt.setString(1, cinStr);
            insertStmt.setString(2, nom);
            insertStmt.setString(3, prenom);
            insertStmt.setString(4, email);
            insertStmt.setString(5, password);
            
            int rowsInserted = insertStmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Registration successful!");
                // Optionally, redirect to Sign_in page:
                new Sign_in().setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Registration failed, please try again.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }                                   
    }//GEN-LAST:event_signUpButtonActionPerformed

    private void cinTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cinTextFieldActionPerformed

    }//GEN-LAST:event_cinTextFieldActionPerformed

    private void goToSignInButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_goToSignInButtonActionPerformed
       new Sign_in().setVisible(true);
        dispose();
    }//GEN-LAST:event_goToSignInButtonActionPerformed

    private void emailTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailTextFieldActionPerformed

    }//GEN-LAST:event_emailTextFieldActionPerformed

    private void prenomTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prenomTextFieldActionPerformed

    }//GEN-LAST:event_prenomTextFieldActionPerformed

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Sign_up().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel SaisirInfo;
    private javax.swing.JLabel SignIN;
    private javax.swing.JLabel cinText;
    private javax.swing.JTextField cinTextField;
    private javax.swing.JLabel emailText;
    private javax.swing.JTextField emailTextField;
    private javax.swing.JButton goToSignInButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel nomText;
    private javax.swing.JTextField nomTextField;
    private javax.swing.JLabel password;
    private javax.swing.JPasswordField passwordField;
    private javax.swing.JLabel prenomText;
    private javax.swing.JTextField prenomTextField;
    private javax.swing.JButton signUpButton;
    // End of variables declaration//GEN-END:variables
}
